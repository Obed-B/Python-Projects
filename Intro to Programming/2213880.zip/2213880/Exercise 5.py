import numpy as np

# Define data types named
studType = np.dtype([('reg_no', 'i4'), ('exam', 'f4'), ('coursework', 'f4'), ('overall', 'f4'), ('grade', 'U15')])

while True:
    # To input file name
    file_name = input("Enter name of the input file: ")
    try:
        # Read the input file
        with open(file_name, 'r') as file:
            # Read and fetch number of students and their coursework weighting in lines
            line = file.readline().split()
            num_of_stud = int(line[0])
            coursework_w = float(line[1]) / 100

            # Initialize student array
            std_data = np.array([(0, 0.0, 0.0, 0.0, "")] * num_of_stud, dtype=studType)

            # To read and populate arrays
            for std in range(num_of_stud):
                line = file.readline().split()
                reg_no = int(line[0])
                exam_score = float(line[1])
                coursework_score = float(line[2])
                overall_score = round(exam_score * (1 - coursework_w) + coursework_score * coursework_w)
                grade = ""
                if exam_score < 30 or coursework_score < 30:
                    grade = "Fail"
                elif overall_score >= 70:
                    grade = "First Class"
                elif 50 <= overall_score <= 69:
                    grade = "Second Class"
                elif 40 <= overall_score <= 49:
                    grade = "Third Class"
                else:
                    grade = "Fail"
                std_data[std] = (reg_no, exam_score, coursework_score, overall_score, grade)

            # Sorting array by overall score
            sorted_data = np.sort(std_data, order='overall')[::-1]

            # Output the sorted array to a file
            output_file_name = file_name
            with open(output_file_name, 'w') as f:
                print(sorted_data, file=f)

            # Compute total number of students with particular grades
            first_class_total = np.count_nonzero(sorted_data['grade'] == 'First Class')

            second_class_total = np.count_nonzero(sorted_data['grade'] == 'Second Class')

            third_class_total = np.count_nonzero(sorted_data['grade'] == 'Third Class')

            fail_total = np.count_nonzero(sorted_data['grade'] == 'Fail')

            # Show results of class computations
            print(f"Total number of first class students: {first_class_total}")

            print(f"Total number of second class students: {second_class_total}")

            print(f"Total number of third class students: {third_class_total}")

            print(f"Total number of failed students: {fail_total}")

            # Failed reg numbers
            failed_reg_no = sorted_data['reg_no'][sorted_data['grade'] == 'Fail']

            if fail_total > 0:
                print(failed_reg_no)

            break

    except FileNotFoundError:
        print("File not found, retry")
