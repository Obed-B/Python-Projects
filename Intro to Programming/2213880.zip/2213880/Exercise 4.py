
# A function defined to take the 3 arguments, a list of tuples and the two integers representing salaries
def employees_info(list_employees, salary_min, salary_max):
    # Creating an empty list to contain employees that match criteria given
    match_employees = []

    """
    Iterate through the list of tuples and check
    If an employee's salary is greater than or 
    equal to the smallest of the integer arguments 
    and less than or equal to the larger 
    then add the employee to the list
    """
    for employees in list_employees:
        if salary_min <= int(employees[2]) <= salary_max:
            match_employees.append(employees)

    # Sort match employees by salary in descending order
    employees_sorted = sorted(match_employees, key=lambda x: int(x[2]), reverse=True)

    # Showing employees that match the criteria in a table format
    print("{:<20} {:<20} {}".format("Name", "Job Title", "Salary"))

    for employees in employees_sorted:
        print("{:<20} {:<20} {}".format(employees[0], employees[1], employees[2]))

    # print an appropriate message if no matches
    if len(match_employees) == 0:
        print("No employees match")


# To open a file for reading
while True:
    file_name = input("Enter a file name: ")
    try:
        with open(file_name, "r") as file:
            # To create an empty list of tuples
            employees_ = []

            # Iterate through the lines of the file
            for e_line in file:
                # Split line into a list of strings
                line_list = e_line.split(",")

                # To convert the list of strings into a tuple then append to the list of tuples
                employees_.append(tuple(line_list))

                print(e_line)

            break
    except FileNotFoundError:
        print("File not found")

while True:
    try:
        # To input salary range from minimum to maximum
        min_sal = int(input("Enter minimum salary: "))
        max_sal = int(input("Enter maximum salary: "))

        # To call the function with the list of tuples, and the two integers
        employees_info(employees_, min_sal, max_sal)

    except ValueError:
        print("Input invalid")

    key = input("Enter 'e' to exit or any other key to continue: ")
    if key.lower() == 'e':
        break
