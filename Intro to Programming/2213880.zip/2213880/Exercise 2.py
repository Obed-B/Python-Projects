import math

def prime(x):
    """
    This function returns True if argument is a
    prime number and False if it isn't.
    """
    if x <= 1:
        return False
    for i in range(2, int(math.sqrt(x)) + 1):
        if x % i == 0:
            return False
    return True

def non_prime(y, z):
    """
    Function defined to take only two positive integers
    as arguments and returns a list of all non-prime
    numbers between the given numbers including the positive
    numbers inclusive.
    """
    if y > z:
        y, z = z, y
    non_primes = []
    for num in range(y, z + 1):
        if not prime(num):
            non_primes.append(num)
    return non_primes

def main():
    """
    A prompt to enter two positive integers then returns
    the list of non-prime numbers including the start and end positive
    integers.
    """
    while True:
        try:
            y = int(input("Start positive integer: "))
            z = int(input("End positive integer: "))
            if y <= 0 or z <= 0:
                raise ValueError("Integer must be positive.")
            break
        except ValueError as error:
            print("Try again:", error)

    # call function to return all non-primes numbers from the argument supplied
    non_primes = non_prime(y, z)

    count = 0
    for num in non_primes:
        print(num, end=" ")
        count += 1
        if count % 10 == 0:
            print()

    if count % 10 != 0:
        print()


if __name__ == "__main__":
    main()
