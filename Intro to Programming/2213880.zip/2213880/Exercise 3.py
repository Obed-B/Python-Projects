# (a)
def is_palindrome(i):
    """
    Returns true if string is a palindrome, converts string
    to lowercase, removes non-alphanumeric characters then
    check if string is equal to its reverse.
    """
    s = ''.join(filter(str.isalnum, i)).lower()
    return i == i[::-1]


# (b)
def most_frequent_string(i):
    # Converts string i to uppercase amd filter's out non-alphanumeric numbers
    i = ''.join(filter(str.isalnum, i)).upper()

    # Count the frequency of each letter/digit
    freq = {}
    for c in i:
        if c in freq:
            freq[c] += 1
        else:
            freq[c] = 1

    # Find the most frequent letter/digit
    max_count = 0
    max_char = ''
    for c in freq:
        if freq[c] > max_count:
            max_count = freq[c]
            max_char = c
    return max_char


# (c)
def count_chars(i):
    # Set all initial counts to zero
    letter_count = 0
    space_count = 0
    digit_count = 0

    # Iterate over characters in the string
    for c in i:
        if c.isalpha():
            letter_count += 1
        elif c.isspace():
            space_count += 1
        elif c.isdigit():
            digit_count += 1

    # Creating a dictionary with the various counts
    counts = {'letters': letter_count, 'spaces': space_count, 'digits': digit_count}
    return counts


print(count_chars("I see you"))
