import datetime
import sys

while True:
    try:
        # To input date of birth in given format
        dob = input("Enter your date of birth (mm/dd/yyyy): ")

        # Parse dob input from string to date format
        dob_date = datetime.datetime.strptime(dob, '%m/%d/%Y')

        # Output returned if date of birth is in the future
        if dob_date > datetime.datetime.now():
            print("Date of birth not valid")
            continue

    except ValueError:
        print("Date format is invalid")
        key = input("press any key to try again or e to exit: ")
        if key == "e":
            sys.exit()

    else:
        # To get today's date
        today = datetime.datetime.now()

        # To verify if the user has had a birthday this year
        if (today.month, today.day) < (dob_date.month, dob_date.day):
            age = today.year - dob_date.year - 1
        else:
            age = today.year - dob_date.year

        # Returning user's age
        print(f"Your age is {age} years old")

        # To output date in European Format
        e_date = dob_date.strftime('%d/%m/%Y')
        print("Your date of birth is: ", e_date)
        sys.exit()
